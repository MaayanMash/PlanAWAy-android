package com.example.maayanmash.planaway;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private List<List<Address>> addressList = null;
    private Location myLocation;
    private static final int MY_LOCATION_REQUEST_CODE = 500;

    public static final int SERVER_PORT = 8889;
    public static final String SERVER_IP = "192.168.1.19";
    private Socket socket;
    private PrintWriter printWriter;

    private List<MyAddress> addressListSend=null;
    private JSONArray jsonArray = new JSONArray();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        this.addressList=new ArrayList<>();
        this.addressListSend= new ArrayList<>();

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        float zoomLevel = 7.0f;
        mMap.getUiSettings().setZoomControlsEnabled(true);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_LOCATION_REQUEST_CODE);
            return;
        }
        mMap.setMyLocationEnabled(true);

        //get my location
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        myLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);


        LatLng israel = new LatLng(31.046051, 34.851611999999996);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(israel, zoomLevel));
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case MY_LOCATION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mMap.setMyLocationEnabled(true);
                }
                break;
        }
    }

    public void addToMap(View view) {
        float zoomLevel = 12.0f;
        EditText locationSearch = (EditText) findViewById(R.id.editText);
        String location = locationSearch.getText().toString();
        List<Address> address = null;
        if (location != null || !location.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            try {
                address = geocoder.getFromLocationName(location, 1);
                addressList.add(address);
                LatLng latLng = new LatLng(address.get(0).getLatitude(), address.get(0).getLongitude());
                this.addressListSend.add(new MyAddress(address.get(0).getLatitude(),address.get(0).getLongitude()));
                this.jsonArray.put(new MyAddress(address.get(0).getLatitude(),address.get(0).getLongitude()).toString());

                mMap.addMarker(new MarkerOptions().position(latLng).title(location));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoomLevel));

            } catch (IOException e) {
                e.printStackTrace();
            }
            locationSearch.setText("");
        }
    }

    public void getDirection(View view) throws JSONException {
        String url= getRequestUrl();
        TaskRequestDirections taskRequestDirections= new TaskRequestDirections(this.mMap);
        taskRequestDirections.execute(url);
    }

    private String getRequestUrl() {
        LatLng origin;
        int size= this.addressList.size();

        if(this.myLocation!=null)
            origin=new LatLng(this.myLocation.getLatitude(),this.myLocation.getLongitude());
        else
            origin = new LatLng(addressList.get(0).get(0).getLatitude(), addressList.get(0).get(0).getLongitude());

        LatLng dest = new LatLng(addressList.get(size-1).get(0).getLatitude(), addressList.get(size-1).get(0).getLongitude());

        String str_org = "origin=" + origin.latitude +","+origin.longitude;
        String str_dest = "destination=" + dest.latitude+","+dest.longitude;

        String str_waypoints="";

        //More than one address & have myLocation
        if (size>=1 && this.myLocation!=null){
            //LatLng waypoints=null;
            str_waypoints="waypoints=optimize:true|";

            LatLng waypoints=new LatLng(addressList.get(0).get(0).getLatitude(), addressList.get(0).get(0).getLongitude());
            str_waypoints+=waypoints.latitude +","+waypoints.longitude;

            for (int i=1; i<addressList.size()-1; i++){
                waypoints=new LatLng(addressList.get(i).get(0).getLatitude(), addressList.get(i).get(0).getLongitude());
                str_waypoints+="|"+waypoints.latitude +","+waypoints.longitude;
            }
        }
        //More than two address & dont have myLocation
        else if (size>=2 && myLocation==null){
            str_waypoints="waypoints=optimize:true|";

            LatLng waypoints=new LatLng(addressList.get(1).get(0).getLatitude(), addressList.get(1).get(0).getLongitude());
            str_waypoints+=waypoints.latitude +","+waypoints.longitude;

            for (int i=2; i<addressList.size()-1; i++){
                waypoints=new LatLng(addressList.get(i).get(0).getLatitude(), addressList.get(i).get(0).getLongitude());
                str_waypoints+="|"+waypoints.latitude +","+waypoints.longitude;
            }
        }
        String sensor = "sensor=false";
        String mode = "mode=driving";
        String param = str_org +"&" + str_dest + "&" +str_waypoints +"&" +sensor+"&" +mode;
        String output = "json";
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + param;

        Log.d("getRequestUrl2",url);
        return url;
    }

    public void sendToServer(View view) {
        Log.d("TAG","server");
        Server server= new Server();
        server.execute("http://192.168.1.19:5000");




    }

}